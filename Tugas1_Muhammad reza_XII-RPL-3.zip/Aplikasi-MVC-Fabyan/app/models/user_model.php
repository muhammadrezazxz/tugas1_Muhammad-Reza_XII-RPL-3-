<?php

class User_model {
    private $nama = 'Fabyan';
    public function getUser() {
        return $this->nama;
    }
};